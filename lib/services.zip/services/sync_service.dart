import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../config/api_config.dart';
import '../models/resultado_envio.dart';
import 'offline_service.dart';

class SyncService {
  static bool _sincronizando = false;

  /// Sincroniza todos los reportes pendientes
  static Future<int> sincronizarPendientes() async {
    if (_sincronizando) {
      return 0;
    }

    _sincronizando = true;

    int enviados = 0;

    try {
      final pendientes = await OfflineService.obtenerPendientes();

      for (final reporte in pendientes) {
        final resultado = await enviarUno(reporte);

        if (resultado.enviado) {
          enviados++;
        }
      }

      return enviados;
    } finally {
      _sincronizando = false;
    }
  }

  /// Sincroniza un solo reporte recién creado
  static Future<ResultadoEnvio> sincronizarReporte(int id) async {
    if (_sincronizando) {
      return const ResultadoEnvio(
        enviado: false,
        mensaje: "Ya existe una sincronización en proceso.",
      );
    }

    _sincronizando = true;

    try {
      final reporte = await OfflineService.obtenerReportePorId(id);

      if (reporte == null) {
        return const ResultadoEnvio(
          enviado: false,
          mensaje: "No se encontró el reporte.",
        );
      }

      return await enviarUno(reporte);
    } finally {
      _sincronizando = false;
    }
  }

  /// Envía un reporte al servidor
  static Future<ResultadoEnvio> enviarUno(
      Map<String, dynamic> reporte) async {

    try {

      await OfflineService.marcarSincronizando(reporte["id"]);

      final prefs = await SharedPreferences.getInstance();

      final token = prefs.getString("token");

      if (token == null || token.isEmpty) {

        return const ResultadoEnvio(
          enviado: false,
          mensaje: "No existe una sesión activa.",
        );

      }

      debugPrint("===== DATOS DEL REPORTE =====");
      debugPrint(reporte.toString());
      debugPrint("=============================");

      final request = http.MultipartRequest(
        "POST",
        Uri.parse("${ApiConfig.baseUrl}/reportes"),
      );

      request.headers["Authorization"] = "Bearer $token";

      request.fields["TipoPlaga"] =
          reporte["tipoPlaga"]?.toString() ?? "";

      request.fields["Descripcion"] =
          reporte["descripcion"]?.toString() ?? "";

      request.fields["Latitud"] =
          reporte["latitud"].toString();

      request.fields["Longitud"] =
          reporte["longitud"].toString();

      request.fields["EstadoUbicacion"] =
          reporte["estado"]?.toString() ?? "";

      request.fields["Municipio"] =
          reporte["municipio"]?.toString() ?? "";

      request.fields["Localidad"] =
          reporte["localidad"]?.toString() ?? "";

      request.fields["CantidadArboles"] =
          reporte["cantidadArboles"].toString();

      final List<String> imagenes = List<String>.from(
        jsonDecode(reporte["imagenes"] as String),
      );

      if (imagenes.isEmpty) {

        await OfflineService.marcarPendiente(
          reporte["id"],
          "Reporte sin fotografías",
        );

        return const ResultadoEnvio(
          enviado: false,
          mensaje: "El reporte no contiene fotografías.",
        );
      }


      debugPrint("Fotografías encontradas: ${imagenes.length}");

      for (final ruta in imagenes) {
        debugPrint("Imagen: $ruta");
      }

      for (final ruta in imagenes) {

        final archivo = File(ruta);

        if (await archivo.exists()) {

          request.files.add(
            await http.MultipartFile.fromPath(
              "Imagenes",
              ruta,
            ),
          );

        }

      }

      final response = await request
          .send()
          .timeout(const Duration(seconds: 20));

      final body = await response.stream.bytesToString();

      debugPrint("Código HTTP: ${response.statusCode}");
      debugPrint("Respuesta API:");
      debugPrint(body);


      if (response.statusCode == 200 ||
          response.statusCode == 201) {

        await OfflineService.marcarEnviado(
          reporte["id"],
        );

        for (final ruta in imagenes) {

          final f = File(ruta);

          if (await f.exists()) {

            try {

              await f.delete();

            } catch (_) {}

          }

        }

        Map<String, dynamic>? respuesta;

        try {

          respuesta = jsonDecode(body);

        } catch (_) {}

        final folio =
        respuesta?["folio"]?.toString();

        return ResultadoEnvio(
          enviado: true,
          folio: folio,
          mensaje: respuesta?["mensaje"]?.toString() ??
              "Reporte enviado correctamente.",
        );

      } else {

        await OfflineService.marcarPendiente(
          reporte["id"],
          "HTTP ${response.statusCode}: $body",
        );

        return ResultadoEnvio(
          enviado: false,
          mensaje:
          "HTTP ${response.statusCode}: $body",
        );

      }

    } catch (e, stack) {

      debugPrint("========== ERROR DE SINCRONIZACIÓN ==========");
      debugPrint("Reporte ID: ${reporte["id"]}");
      debugPrint("Tipo: ${e.runtimeType}");
      debugPrint("Mensaje: $e");
      debugPrint(stack.toString());
      debugPrint("=============================================");

      try {
        await OfflineService.marcarPendiente(
          reporte["id"],
          e.toString(),
        );
      } catch (_) {}

      return ResultadoEnvio(
        enviado: false,
        mensaje: e.toString(),
      );

    }

  }

}