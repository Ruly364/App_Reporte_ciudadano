import '../models/gps_capture_progress.dart';
import '../models/gps_capture_session.dart';
import '../models/gps_configuration.dart';
import '../models/gps_profile.dart';
import '../models/gps_state.dart';
import '../models/location_result.dart';

import 'gps_report_builder.dart';
import 'gps_session.dart';

/// ===============================================================
/// GPS CONTROLLER
/// ---------------------------------------------------------------
/// Coordina una captura GPS.
///
/// Responsabilidades:
///
/// ✔ Iniciar captura
/// ✔ Cancelar captura
/// ✔ Reiniciar
/// ✔ Exponer progreso
/// ✔ Obtener la sesión final
///
/// NO calcula Score.
/// NO procesa GPS.
/// NO usa Geolocator.
/// ===============================================================

class GpsController {

  final GpsSession _session = GpsSession();

  final GpsReportBuilder _builder = GpsReportBuilder();

  //------------------------------------------------------------
  // Configuración actual
  //------------------------------------------------------------

  GpsConfiguration _configuration =
      GpsProfile.altaPrecision.configuration;

  //------------------------------------------------------------
  // Resultado final
  //------------------------------------------------------------

  GpsCaptureSession? _captureSession;

  //------------------------------------------------------------
  // Getters
  //------------------------------------------------------------

  GpsState get state => _session.state;

  bool get isBusy =>

      state != GpsState.idle &&
          state != GpsState.completed &&
          state != GpsState.cancelled &&
          state != GpsState.timeout;

  double get score => _session.score;

  LocationResult? get bestLocation =>
      _session.bestLocation;

  GpsCaptureSession? get captureSession =>
      _captureSession;

  //------------------------------------------------------------
  // Configurar perfil
  //------------------------------------------------------------

  void setProfile(GpsProfile profile) {

    _configuration = profile.configuration;

  }

  //------------------------------------------------------------
  // Iniciar captura
  //------------------------------------------------------------

  Future<GpsCaptureSession?> capture() async {

    final location = await _session.capture(

      configuration: _configuration,

    );

    if (location == null) {

      return null;

    }

    _captureSession = _builder.build(

      session: _session,

      configuration: _configuration,

    );

    return _captureSession;

  }

  //------------------------------------------------------------
  // WarmUp
  //------------------------------------------------------------

  Future<void> warmUp() async {

    await _session.warmUp(

      configuration: _configuration,

    );

  }

  //------------------------------------------------------------
  // Cancelar
  //------------------------------------------------------------

  Future<void> cancel() async {

    await _session.cancel();

  }

  //------------------------------------------------------------
  // Reiniciar
  //------------------------------------------------------------

  void reset() {

    _captureSession = null;

    _session.reset();

  }

  //------------------------------------------------------------
  // Dashboard
  //------------------------------------------------------------

  GpsCaptureProgress progress() {

    return _builder.progress(

      session: _session,

      configuration: _configuration,

    );

  }

  //------------------------------------------------------------
  // Dispose
  //------------------------------------------------------------

  Future<void> dispose() async {

    await _session.cancel();

  }

}