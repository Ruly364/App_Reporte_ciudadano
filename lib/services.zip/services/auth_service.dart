import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:plagas_app/config/api_config.dart';

class AuthService {

  /// LOGIN con correo O teléfono
  static Future<Map<String, dynamic>?> login({
    String? email,
    String? telefono,
    required String password,
  }) async {

    // ✅ Construimos el body correctamente
    final Map<String, dynamic> body = {
      'password': password,
    };

    if (email != null && email.isNotEmpty) {
      body['email'] = email;
    }

    if (telefono != null && telefono.isNotEmpty) {
      body['telefono'] = telefono;
    }

    final response = await http.post(
      Uri.parse('${ApiConfig.baseUrl}/auth/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(body), // ✅ Ahora sí usamos el body construido arriba
    );

    print('STATUS: ${response.statusCode}');
    print('BODY: ${response.body}');

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);

      // ✅ Verificamos que el backend devuelva el rol
      print('ROL recibido: ${data['rol']}');

      return data;
    }
    return null;
  }

  /// REGISTER con correo, teléfono o ambos
  static Future<String> register(
      String nombre,
      String? email,
      String? telefono,
      String password,
      int edad,
      String genero,
      String estado,
      String municipio,
      bool esEtnia,
      String etnia,
      ) async {

    final response = await http.post(
      Uri.parse('${ApiConfig.baseUrl}/auth/register'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'nombre': nombre,
        'email': email,
        'telefono': telefono,
        'password': password,
        'edad': edad,
        'genero': genero,
        'estado': estado,
        'municipio': municipio,
        'esEtnia': esEtnia,
        'etnia': esEtnia ? etnia : null,
      }),
    );

    if (response.statusCode == 200) return "OK";
    return response.body;
  }
}