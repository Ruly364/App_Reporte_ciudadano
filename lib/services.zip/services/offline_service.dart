import 'dart:convert';

import 'package:sqflite/sqflite.dart';
import 'package:uuid/uuid.dart';

import 'local_db.dart';

class OfflineService {

  static const _uuid = Uuid();

  static Future<int> guardarReporte(
      Map<String, dynamic> data) async {

    final db = await LocalDB.database;

    return await db.insert(

      'reportes',

      {

        'uuid': _uuid.v4(),

        'tipoPlaga':
        data['tipoPlaga']?.toString() ?? '',

        'descripcion':
        data['descripcion']?.toString() ?? '',

        'latitud':
        (data['latitud'] as num?)?.toDouble() ?? 0,

        'longitud':
        (data['longitud'] as num?)?.toDouble() ?? 0,

        'estado':
        data['estado']?.toString() ?? '',

        'municipio':
        data['municipio']?.toString() ?? '',

        'localidad':
        data['localidad']?.toString() ?? '',

        'cantidadArboles':
        (data['cantidadArboles'] as num?)?.toInt() ?? 0,

        'imagenes': data['imagenes'] is String
            ? data['imagenes']
            : jsonEncode(data['imagenes'] ?? []),

        'fecha':
        data['fecha']?.toString() ??
            DateTime.now().toIso8601String(),

        'status': 'pendiente',

        'fechaSincronizacion': null,

        'intentos': 0,

        'ultimoError': null,

        'sincronizando': 0,
      },

      conflictAlgorithm:
      ConflictAlgorithm.replace,
    );
  }

  static Future<Map<String, dynamic>?> obtenerReportePorId(int id) async {

    final db = await LocalDB.database;

    final resultado = await db.query(
      'reportes',
      where: 'id = ?',
      whereArgs: [id],
      limit: 1,
    );

    if (resultado.isEmpty) {
      return null;
    }

    return resultado.first;
  }

  static Future<List<Map<String, dynamic>>>
  obtenerPendientes() async {

    final db = await LocalDB.database;

    return db.query(

      'reportes',

      where:
      'status = ? AND sincronizando = 0',

      whereArgs: ['pendiente'],

      orderBy: 'fecha ASC',
    );
  }

  static Future<void> marcarSincronizando(
      int id) async {

    final db = await LocalDB.database;

    await db.update(

      'reportes',

      {

        'sincronizando': 1,

      },

      where: 'id=?',

      whereArgs: [id],
    );
  }

  static Future<void> marcarPendiente(
      int id,
      String error,
      ) async {

    final db = await LocalDB.database;

    await db.rawUpdate('''

UPDATE reportes

SET

status='pendiente',

sincronizando=0,

intentos=intentos+1,

ultimoError=?

WHERE id=?

''', [error, id]);
  }

  static Future<void> marcarEnviado(
      int id) async {

    final db = await LocalDB.database;

    await db.update(

      'reportes',

      {

        'status': 'enviado',

        'sincronizando': 0,

        'fechaSincronizacion':
        DateTime.now().toIso8601String(),

        'ultimoError': null,

      },

      where: 'id=?',

      whereArgs: [id],
    );
  }

  static Future<List<Map<String, dynamic>>>
  obtenerTodos() async {

    final db = await LocalDB.database;

    return db.query(

      'reportes',

      orderBy: 'fecha DESC',
    );
  }

  static Future<void> eliminarReporte(
      int id) async {

    final db = await LocalDB.database;

    await db.delete(

      'reportes',

      where: 'id=?',

      whereArgs: [id],
    );
  }

  static Future<int> pendientes() async {

    final db = await LocalDB.database;

    final r = Sqflite.firstIntValue(

      await db.rawQuery(

          'SELECT COUNT(*) FROM reportes WHERE status="pendiente"'),
    );

    return r ?? 0;
  }

  static Future<int> enviados() async {

    final db = await LocalDB.database;

    final r = Sqflite.firstIntValue(

      await db.rawQuery(

          'SELECT COUNT(*) FROM reportes WHERE status="enviado"'),
    );

    return r ?? 0;
  }

  static Future<void> limpiarEnviados() async {

    final db = await LocalDB.database;

    await db.delete(

      'reportes',

      where: 'status=?',

      whereArgs: ['enviado'],
    );
  }

  static Future<void> guardarCatalogo(
      List<dynamic> catalogo) async {

    final db = await LocalDB.database;

    final batch = db.batch();

    batch.delete("catalogo_plagas");

    for (final item in catalogo) {

      batch.insert(

        "catalogo_plagas",

        {

          "id": item.id,

          "nombre": item.nombre,

        },
        conflictAlgorithm: ConflictAlgorithm.replace,

      );

    }

    await batch.commit(noResult: true);

    await guardarConfiguracion(

      "catalogo_plagas_fecha",

      DateTime.now().toIso8601String(),

    );



  }

  static Future<bool> necesitaActualizarCatalogo() async {

    final fecha =
    await obtenerConfiguracion(
        "catalogo_plagas_fecha");

    if (fecha == null) {

      return true;

    }

    final ultima =
    DateTime.tryParse(fecha);

    if (ultima == null) {

      return true;

    }

    final ahora = DateTime.now();

    return ahora.difference(ultima).inHours >= 24;

  }


  /// Obtiene el catálogo almacenado localmente
  static Future<List<Map<String,dynamic>>>
  obtenerCatalogo() async {

    final db = await LocalDB.database;

    return await db.query(

      "catalogo_plagas",

      orderBy: "nombre",

    );

  }

  static Future<bool> existeCatalogo() async {

    final db = await LocalDB.database;

    final cantidad = Sqflite.firstIntValue(

      await db.rawQuery(

        'SELECT COUNT(*) FROM catalogo_plagas',

      ),

    );

    return (cantidad ?? 0) > 0;

  }

  static Future<void> limpiarCatalogo() async {

    final db = await LocalDB.database;

    await db.delete('catalogo_plagas');

  }

  static Future<void> guardarConfiguracion(
      String clave,
      String valor) async {

    final db = await LocalDB.database;

    await db.insert(

      'configuracion',

      {

        'clave': clave,

        'valor': valor,

      },

      conflictAlgorithm: ConflictAlgorithm.replace,

    );

  }

  static Future<String?> obtenerConfiguracion(
      String clave) async {

    final db = await LocalDB.database;

    final resultado = await db.query(

      'configuracion',

      where: 'clave=?',

      whereArgs: [clave],

      limit: 1,

    );

    if (resultado.isEmpty) {

      return null;

    }

    return resultado.first["valor"] as String?;

  }




}