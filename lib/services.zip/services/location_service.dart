import 'package:geolocator/geolocator.dart';

import '../models/location_quality.dart';
import '../models/location_result.dart';
import '../models/location_source.dart';

class LocationService {
  LocationService._();

  //==============================================================
  // PERMISOS
  //==============================================================

  static Future<bool> ensurePermission() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      return false;
    }

    var permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      return false;
    }

    return true;
  }

  //==============================================================
  // ÚLTIMA POSICIÓN
  //==============================================================

  static Future<LocationResult?> lastKnown() async {
    if (!await ensurePermission()) return null;

    final position = await Geolocator.getLastKnownPosition();

    if (position == null) return null;

    return _fromPosition(position);
  }

  //==============================================================
  // POSICIÓN ACTUAL
  //==============================================================

  static Future<LocationResult?> current() async {
    if (!await ensurePermission()) return null;

    final position = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.bestForNavigation,
    );

    return _fromPosition(position);
  }

  //==============================================================
  // STREAM
  //==============================================================

  static Stream<LocationResult> listen({
    LocationAccuracy accuracy = LocationAccuracy.bestForNavigation,
    int distanceFilter = 0,
  }) {
    return Geolocator.getPositionStream(
      locationSettings: LocationSettings(
        accuracy: accuracy,
        distanceFilter: distanceFilter,
      ),
    ).map(_fromPosition);
  }

  //==============================================================
  // CONVERSIÓN
  //==============================================================

  static LocationResult _fromPosition(Position p) {
    return LocationResult(
      latitude: p.latitude,
      longitude: p.longitude,
      altitude: p.altitude,
      accuracy: p.accuracy,
      verticalAccuracy: p.altitudeAccuracy,
      heading: p.heading,
      speed: p.speed,
      source: LocationSource.androidGps,
      quality: _quality(p.accuracy),
      satellites: 0,
      hdop: null,
      vdop: null,
      pdop: null,
      rtkFix: false,
      timestamp: p.timestamp ?? DateTime.now(),
    );
  }

  //==============================================================
  // CALIDAD
  //==============================================================

  static LocationQuality _quality(double accuracy) {
    if (accuracy <= 2) {
      return LocationQuality.excellent;
    }

    if (accuracy <= 5) {
      return LocationQuality.veryGood;
    }

    if (accuracy <= 10) {
      return LocationQuality.good;
    }

    if (accuracy <= 20) {
      return LocationQuality.fair;
    }

    return LocationQuality.poor;
  }
}